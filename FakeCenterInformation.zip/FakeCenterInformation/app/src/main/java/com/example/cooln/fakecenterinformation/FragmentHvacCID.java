package com.example.cooln.fakecenterinformation;

import android.support.v4.app.Fragment;

public class FragmentHvacCID extends Fragment {

}
