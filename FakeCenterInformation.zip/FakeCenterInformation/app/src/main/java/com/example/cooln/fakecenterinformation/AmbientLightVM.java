package com.example.cooln.fakecenterinformation;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

public class AmbientLightVM extends AndroidViewModel {

    public AmbientLightVM(@NonNull final Application application) {
        super(application);
    }
}
